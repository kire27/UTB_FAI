
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5 import uic
try:
    from func.functions import ui_print, modulo_inverse, gcd, value_filter, recursive_separation, remove_special_alphabet
except:
    from src.func.functions import ui_print, modulo_inverse, gcd, value_filter, recursive_separation, remove_special_alphabet

gui_path = "src/res/gui_v4.ui"

ALPHABET = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","R","Q","S","T","U","V","W","X","Y","Z"]
SPECIAL_ALPHABET = {
    " ": "XMEZERAX",
    "1": "XJEDNAX",
    "2": "XDVAX",
    "3": "XTRIX",
    "4": "XCTYRIX",
    "5": "XPETX",
    "6": "XSESTX",
    "7": "XSEDMX",
    "8": "XOSMX",
    "9": "XDEVETX",
    "0": "XNULAX",
}
DIACRITIC_ALPHABET = {
    "Á": "A",
    "Č": "C",
    "Ď": "D",
    "É": "E",
    "Ě": "E",
    "Í": "I",
    "Ň": "N",
    "Ó": "O",
    "Ř": "R",
    "Š": "S",
    "Ť": "T",
    "Ú": "U",
    "Ů": "U",
    "Ý": "Y",
    "Ž": "Z",
}

ui_main_window, qt_base_class = uic.loadUiType(gui_path)
 
class MyApp(QMainWindow, ui_main_window):        

    def __init__(self):
        self._m = len(ALPHABET)
        QMainWindow.__init__(self)
        ui_main_window.__init__(self)
        self.setupUi(self)
        self.button_get_encryption.clicked.connect(self.get_encryption)
        self.button_get_decryption.clicked.connect(self.get_decryption)
        
        ui_print(self, "allowed characters -- " + str(ALPHABET + list(SPECIAL_ALPHABET.keys()) + list(DIACRITIC_ALPHABET.keys())))


    def display_encryption(self, value):
        display = "".join(recursive_separation(value, 5, " "))
        ui_print(self, "encrypted value -- " + display)
        self.textEdit_encrypt_value.setPlainText(display)


    def display_decryption(self, value):
        display = remove_special_alphabet("".join(value), SPECIAL_ALPHABET)
        ui_print(self, "decrypted value -- " + display)
        self.textEdit_decrypt_value.setPlainText(display)


    def showError(self, error_msg):
        error_message = QMessageBox()
        error_message.setWindowTitle('Error')
        error_message.setText(str(error_msg))
        error_message.setStandardButtons(QMessageBox.Ok)
        error_message.exec_()


    def get_encryption(self):
        try:
            value = str(self.input_encrypt_value.text())
            keyA = int(self.input_encrypt_key_a.text())
            keyB = int(self.input_encrypt_key_b.text())
            
            if gcd(keyA, self._m) != 1:
                raise ValueError('keyA a velikost abecedy nejsou nesoudělné, šifru nelze použít.')
        
            if modulo_inverse(keyA, self._m) is None: 
                raise ValueError('šifru nelze použít.')
        
            filtered_value = value_filter(value, ALPHABET, SPECIAL_ALPHABET, DIACRITIC_ALPHABET)
            char_index = [ALPHABET.index(char) for char in filtered_value]

            ui_print(self, "filtered input -- " + str(filtered_value))
            ui_print(self, "input indexes -- " + str(char_index))

            encrypted_value = []
                
            for index in char_index:
                encrypted_index = (keyA * index + keyB) % self._m
                encrypted_value.append(ALPHABET[encrypted_index])
            
            self.display_encryption(encrypted_value)
            return encrypted_value
        except Exception as e:
            self.showError(e)


    def get_decryption(self):
        try:
            value = str(self.input_decrypt_value.text())
            keyA = int(self.input_decrypt_key_a.text())
            keyB = int(self.input_decrypt_key_b.text())

            if gcd(keyA, self._m) != 1: 
                raise ValueError('keyA a velikost abecedy nejsou nesoudělné, šifru nelze použít.')

            keyA_inv = modulo_inverse(keyA, self._m)

            if keyA_inv is None: 
                raise ValueError('šifru nelze použít.')
            
            decrypted_value = []

            for char in value.replace(" ", ""):
                y = ALPHABET.index(char)
                decrypted_index = (keyA_inv * (y - keyB)) % self._m
                decrypted_value.append(ALPHABET[decrypted_index])

            self.display_decryption(decrypted_value)
            return decrypted_value
        except Exception as e:
            self.showError(e)

