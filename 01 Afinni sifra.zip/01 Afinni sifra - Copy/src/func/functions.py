from datetime import datetime
from PyQt5.QtWidgets import QMessageBox


def ui_print(ui, value:str):
    '''Console log into ui
    :ui - class element
    :value - text to display
    '''
    text = ui.textEdit_terminal_output.toPlainText()
    new_text = datetime.now().strftime("%H:%M:%S.%f")[:-3] + " | " + str(value)+ '\n' + text+'\n'
    ui.textEdit_terminal_output.setPlainText(new_text)
              

def gcd(a, b):
    '''Euclid's algorithm for finding the greatest common divisor'''
    if b == 0: return a
    return gcd(b, a % b)


def modulo_inverse(a, m, index=1):
    '''Modular inversion, 'a' exists only if the numbers 'a' and 'm' are odd (their GCD is 1)'''
    if index == m-1: return None
    if (a * index) % m == 1: return index
    return modulo_inverse(a, m, index+1)


def recursive_separation(list:list, index:int, element:any, _i=0) -> list:
    '''Recursively separate list at every instance of index length in list'''
    if _i+index >= len(list): return list        # if i+5 is bigger than list length then we don't have to insert element
    return recursive_separation(
        list[:_i+index] + [element] + list[_i+index:], 
        index,
        element,
        _i+index+1
    )


def remove_special_alphabet(string:str, replacements:dict) -> str:
    for key, value in replacements.items():
        string = string.replace(value, key)
    return string


def value_filter(value: str, alphabet:list, special_alphabet:dict, diacritic_alphabet:dict) -> str:
    allowed_chars = alphabet + list(special_alphabet.keys()) + list(diacritic_alphabet.keys())
    new_value = list(value.upper())
    chars = "".join(list(filter(lambda x: x in allowed_chars, new_value)))

    for key, value in special_alphabet.items():
        chars = chars.replace(key, value)
    for key,value in diacritic_alphabet.items():
        chars = chars.replace(key, value)

    return chars
