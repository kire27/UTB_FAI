from src.app import QApplication, MyApp
import sys

app = QApplication(sys.argv)
window = MyApp()
window.show()
sys.exit(app.exec_())