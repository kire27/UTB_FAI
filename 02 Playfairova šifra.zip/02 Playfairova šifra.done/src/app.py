from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5 import uic
import os
try:
	from src.func.functions import ui_print, alarm_on_user_password, checkedLan, display_encryption, display_decryption, showError
	from src.func.string import text_filter_remove_duplicates, recursive_separation, \
		insert_x_replace_special_chars, text_filter_remove_diacritics_chars, filter_user_input, remove_x_replace_special_chars
	from src.func.cipher import create_matrix, encrypt_decrypt_cipher
except:
	raise Exception

gui_dir = os.path.dirname(os.path.realpath(__file__))
gui_path = os.path.join(gui_dir, "res/gui.ui")
print(gui_path)

LANGUAGE_RULES = {
	"cz": {
		"odd_dupl": ["X", "Q"],
		"replacable": ["W", "V"],
		"alphabet": ["A","B","C","D","E",   "F","G","H","I","J",    "K","L","M","N","O",    "P","Q","R","S","T",    "U","V","X","Y","Z"]
	},
	"en": {
		"odd_dupl": ["X", "Z"],
		"replacable": ["Q", "K"],
		"alphabet": ["A","B","C","D","E",   "F","G","H","I","J",    "K","L","M","N","O",    "P","R","S","T","U",    "V","W","X","Y","Z"]
	}
}

SPECIAL_ALPHABET = {
	# Values have to have even number in length
	" ": "XMEZERAX",
	"1": "XJEDNAJX",
	"2": "XDVADX",
	"3": "XTRITX",
	"4": "XCTYRICX",
	"5": "XPETPX",
	"6": "XSESTX",
	"7": "XSEDMX",
	"8": "XOSMOX",
	"9": "XDEVETDX",
	"0": "XNULAX",
}
DIACRITIC_ALPHABET = {
	"Á": "A",
	"Č": "C",
	"Ď": "D",
	"É": "E",
	"Ě": "E",
	"Í": "I",
	"Ň": "N",
	"Ó": "O",
	"Ř": "R",
	"Š": "S",
	"Ť": "T",
	"Ú": "U",
	"Ů": "U",
	"Ý": "Y",
	"Ž": "Z",
}

ui_main_window, qt_base_class = uic.loadUiType(gui_path)

class MyApp(QMainWindow, ui_main_window):        
	
	def __init__(self):
		QMainWindow.__init__(self)
		ui_main_window.__init__(self)
		self.setupUi(self)
		self.radioButton_cz.setChecked(True)
		self.radioButton_cz.toggled.connect(
			lambda: ui_print(self, "allowed characters = " 
					+ str(LANGUAGE_RULES[checkedLan(self)]["alphabet"] 
		   			+ list(SPECIAL_ALPHABET.keys()) 
					+ list(DIACRITIC_ALPHABET.keys()))
					+"\n"))
		self.button_encrypt.clicked.connect(self.encrypt)
		self.button_decrypt.clicked.connect(self.decrypt)

		ui_print(self, "allowed characters = " 
					+ str(LANGUAGE_RULES[checkedLan(self)]["alphabet"] 
		   			+ list(SPECIAL_ALPHABET.keys()) 
					+ list(DIACRITIC_ALPHABET.keys())))
		

	def encrypt(self):
		try:
			lang_rules = LANGUAGE_RULES[checkedLan(self)]
			password = str(self.input_encrypt_password.text()).upper()
			text = str(self.input_encrypt_text.text()).upper()

			alarm_on_user_password(password, lang_rules)
			
			ui_print(self, "\n")

			ui_print(self, "USER PASSWORD = " + password)
			ui_print(self, "USER INPUT = " + text)
			
			filtered_password = text_filter_remove_duplicates(
				text_filter_remove_diacritics_chars(list(password), lang_rules["alphabet"], DIACRITIC_ALPHABET | SPECIAL_ALPHABET)
			)
			ui_print(self, "FILTERED PASSWORD = " + "".join(filtered_password))
				
			filtered_text = insert_x_replace_special_chars(
				filter_user_input(list(text), lang_rules["alphabet"], list(SPECIAL_ALPHABET.keys()), DIACRITIC_ALPHABET), 
				lang_rules, 
				SPECIAL_ALPHABET
			)
			ui_print(self, "FILTERED INPUT = " + "".join(
				recursive_separation(list(filtered_text), 2, " ")
			))
			
			matrix = create_matrix(list(filtered_password), lang_rules["alphabet"])
			ui_print(self, "MATRIX = \n" + "\n".join(" | ".join(row) for row in matrix))
			
			output = encrypt_decrypt_cipher(list(filtered_text), matrix, True)
			ui_print(self, "ENCRYPTED TEXT = " + output)
			
			display_encryption(self, output)

			return output
		except Exception as e:
			showError(e)


	def decrypt(self):
		try:
			lang_rules = LANGUAGE_RULES[checkedLan(self)]
			password = str(self.input_decrypt_password.text()).upper()
			text = str(self.input_decrypt_text.text()).upper().replace(" ", "")

			ui_print(self, "\n")
			ui_print(self, "USER PASSWORD = " + "".join(password))
			ui_print(self, "USER INPUT = " + "".join(text))
			
			filtered_password = text_filter_remove_duplicates(
				text_filter_remove_diacritics_chars(list(password), lang_rules["alphabet"], SPECIAL_ALPHABET | DIACRITIC_ALPHABET)
			)
			ui_print(self, "FILTERED PASSWORD = " + "".join(filtered_password))

			matrix = create_matrix(filtered_password, lang_rules["alphabet"])
			ui_print(self, "MATRIX = \n" + "\n".join(" | ".join(row) for row in matrix))
			
			output = encrypt_decrypt_cipher(list(text), matrix, False)
			ui_print(self, "DECRYPTION OUTPUT ===== " + output)
			filtered_output = remove_x_replace_special_chars(output, lang_rules, SPECIAL_ALPHABET)
			ui_print(self, "DECRYPTED TEXT ===== " + filtered_output)
			# filtered_output = text_filter_remove_x(output, lang_rules)
			# output_readable = text_filter_add_non_ordinary_chars(filtered_output, SPECIAL_ALPHABET)
			# ui_print(self, "READABLE DECRYPTION ===== " + output_readable)

			display_decryption(self, filtered_output)

			return filtered_output
		except Exception as e:
			showError(e)

