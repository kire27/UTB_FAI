from datetime import datetime
from PyQt5.QtWidgets import QMessageBox

try: from src.func.string import recursive_separation
except: from func.string import recursive_separation


def alarm_on_user_password(input:str, lang_rules:dict):
	input = list(set(input))
	if len(input) < 5 or len(input) > 25:
		raise Exception('Heslo nemůže být menší než 8 znaků a větší než 25 znaků bez duplikace.')
	if lang_rules["replacable"][0] in input:
		raise Exception(f'Heslo nemůže obsahovat písmeno "{lang_rules["replacable"][0]}"',)


def ui_print(ui, value:str):
	'''Console log into ui
	:ui - class element
	:value - text to display
	'''
	text = ui.textEdit_terminal_output.toPlainText()
	new_text = datetime.now().strftime("%H:%M:%S.%f")[:-3] + " | " + str(value)+ '\n' + text+'\n'
	ui.textEdit_terminal_output.setPlainText(new_text)


def checkedLan(self):
	if self.radioButton_cz.isChecked():
		return "cz"
	else:
		return "en"


def display_encryption(self, value):
	self.textEdit_encrypt_output.setPlainText(
		"".join(
			recursive_separation(list(value), 5, " ")
		)
	)


def display_decryption(self, value):
	# ui_print(self, "decrypted value ===== " + value)
	self.textEdit_decrypt_output.setPlainText(value)


def showError(error_msg):
	error_message = QMessageBox()
	error_message.setWindowTitle('Error')
	error_message.setText(str(error_msg))
	error_message.setStandardButtons(QMessageBox.Ok)
	error_message.exec_()