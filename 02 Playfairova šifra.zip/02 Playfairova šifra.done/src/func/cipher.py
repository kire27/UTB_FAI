try: from src.func.string import text_filter_remove_duplicates
except: from func.string import text_filter_remove_duplicates

def create_matrix(password:list, alphabet:list) -> list[list]:
	'''Create matrix 5x5. Matrix will contain letters from `alphabet` while letters from `password` will be at the beginning. Letters will not duplicate.'''
	matrix = []
	filtered_alphabet = list(filter(lambda x: x not in password, alphabet))
	
	for i in range(0, 25, 5):
		matrix.append(
			(password+filtered_alphabet)[i:i+5]
		)

	return matrix


def encrypt_decrypt_cipher(finput: list, matrix: list[list], mode:bool=True, _args:list=[0,[0,0],[0,0],""]) -> str:
	''':finput - filtered input
	:mode - true/encrypt, false/decrypt'''

	# _index = iterates over filtered input, till reaching max length
	# [y0, x0], [y1, x1] = holds position indexes of first or second character in matrix
	_index, [y1, x1], [y0, x0], password = _args

	if _index >= len(finput): 
		return password
	
	for x in range(len(matrix)):
		for y in range(len(matrix[x])):
			if (matrix[x][y] == finput[_index]):
				[y1, x1] = [x, y]

	if _index % 2 != 0:
		# horizontal rule
		if y0 == y1:
			mx0 = (x0+1)%5 if mode else (x0-1)%5
			mx1 = (x1+1)%5 if mode else (x1-1)%5
			password = password + matrix[y0][mx0] + matrix[y1][mx1] 

		# vertical rule
		elif x0 == x1: 
			my0 = (y0+1)%5 if mode else (y0-1)%5
			my1 = (y1+1)%5 if mode else (y1-1)%5
			password = password + matrix[my0][x0] + matrix[my1][x1]

		# diagonal rule
		else:
			password = password + matrix[y0][x1] + matrix[y1][x0] 

	return encrypt_decrypt_cipher(finput, matrix, mode, [_index+1, [y0, x0], [y1, x1], password])





