def recursive_separation(list:list, index:int, element:any, _i=0) -> list:
	'''Recursively separate list at every instance of index length in list'''
	if _i+index >= len(list): return list        # if i+5 is bigger than list length then we don't have to insert element
	return recursive_separation(
		list[:_i+index] + [element] + list[_i+index:], 
		index,
		element,
		_i+index+1
	)


def filter_user_input(value: list, alphabet:list, to_allow:list, to_replace:dict) -> str:
	allowed_chars = alphabet + to_allow + list(to_replace.keys())
	chars = "".join(list(filter(
		lambda x: x in allowed_chars, list(value)
	)))

	for key, val in to_replace.items():
		chars = chars.replace(key, val)

	return chars


def text_filter_remove_diacritics_chars(value: list, alphabet:list, to_replace:dict) -> list:
	allowed_chars = alphabet + list(to_replace.keys())
	chars = "".join(list(filter(
		lambda x: x in allowed_chars, list(value)
	)))

	for key, val in to_replace.items():
		chars = chars.replace(key, val)

	return chars


def text_filter_remove_duplicates(value: str) -> list:
	return list(dict.fromkeys(value))


def insert_x_replace_special_chars(input:str, lang_rules:dict, special_alphabet:dict) -> str:
	'''if odd_dupl are inserted between filtered text and filtered special characters there is guaranteed error in decryption. not fixable !'''
		
	dupl_insert = lambda char: lang_rules["odd_dupl"][1 if char == lang_rules["odd_dupl"][0] else 0]

	# remove odd pairs of special characters with '.' placeholder

	for schar in list(special_alphabet.keys()):
		if schar in input:
			input_list = input.split(schar)
			input = f"{schar}.".join(input_list)

	input:list = list(input)

	# insert 'x' or 'q' between duplicating characters in text only
	
	i = 0
	while i < len(input)-1:
		if (input[i] == input[i+1]):
			input.insert(i+1, dupl_insert(input[i]))
			i+=2
		else:
			i+=1

	# replace special characters with substitutes

	input:str = "".join(input).replace(".", "")

	for schar in list(special_alphabet.keys()):
		if schar in input:
			input = input.replace(schar, special_alphabet[schar])

	# add 'x | q' at the end of input if length is odd 

	if len(input) % 2 == 1:
		input = input + dupl_insert(input[-1])

	return input
		

def remove_x_replace_special_chars(input:str, lang_rules:dict, special_alphabet:dict) -> str:
	def text_filter_remove_x(value:list, lang_rules, _index=0):
		if len(value) < _index+3: return value

		if value[_index] == value[_index+2] and \
		value[_index+1] == lang_rules["odd_dupl"][0] or \
		value[_index+1] == lang_rules["odd_dupl"][1]:
			return text_filter_remove_x(
				value[:_index+1]+value[_index+2:],
				lang_rules,
				_index+2
			)
		else:
			return text_filter_remove_x(value, lang_rules, _index+1)

	# add 'x | q' at the end of input if length is odd 

	last_char_exeption = True
	if len(input) % 2 == 0:
		# if last char is X or if last char is X and second is Q. remove last char

		for key, value in special_alphabet.items():
			if value not in input: continue

			if input[-len(value):] == value:
				last_char_exeption = False

		if last_char_exeption and (
			input[-1] == lang_rules["odd_dupl"][0] or \
				(input[-2] == lang_rules["odd_dupl"][0] and \
				input[-1] == lang_rules["odd_dupl"][1])
		):
			input = input[:-1]

	# replace alphabetical special characters for the actual characters

	for key, value in special_alphabet.items():
		input = input.replace(value, key)
	
	# remove special character insertion

	input:list = text_filter_remove_x(list(input), lang_rules)

	return "".join(input)


