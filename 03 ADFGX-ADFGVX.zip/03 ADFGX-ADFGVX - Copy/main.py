from src.app import QApplication, MyApp
import sys

app = QApplication(sys.argv)
window = MyApp()
window.show()
sys.exit(app.exec_())


'''help
https://www.youtube.com/watch?v=iwd19KMXTYI
https://en.wikipedia.org/wiki/ADFGVX_cipher
'''