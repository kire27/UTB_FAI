from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5 import uic
from datetime import datetime
import os

try:
	import src.func.gui as gui
	import src.func.cipher as cph 
	import src.func.table as tb
	import src.func.files as fs
	import src.func.filters as ftr
except:
	import func.gui as gui
	import func.cipher as cph 
	import func.table as tb
	import func.files as fs
	import func.filters as ftr


gui_dir = os.path.dirname(os.path.realpath(__file__))
gui_path = os.path.join(gui_dir, "res/gui.ui")

LANGUAGE_RULES = {
	"5": {
		"replacable": ["W", "V"],
		"alphabet": [
			"A","B","C","D","E",   
			"F","G","H","I","J",    
			"K","L","M","N","O",    
			"P","Q","R","S","T",    
			"U","V","X","Y","Z"
		],
		"special": {
			" ": "XMEZERAX",
			"1": "XJEDNAJX",
			"2": "XDVADX",
			"3": "XTRITX",
			"4": "XCTYRICX",
			"5": "XPETPX",
			"6": "XSESTX",
			"7": "XSEDMX",
			"8": "XOSMOX",
			"9": "XDEVETDX",
			"0": "XNULAX",
		}
	},
	"6": {
		"alphabet": [
			"A","B","C","D","E","F",
			"G","H","I","J","K","L",
			"M","N","O","P","Q","R",
			"S","T","U","V","W","X",
			"Y","Z","0","1","2","3",
			"4","5","6","7","8","9",
		],
		"special": {
			" ": "XMEZERAX"
		}
	},
	"diacritics": {
		"Á": "A",
		"Č": "C",
		"Ď": "D",
		"É": "E",
		"Ě": "E",
		"Í": "I",
		"Ň": "N",
		"Ó": "O",
		"Ř": "R",
		"Š": "S",
		"Ť": "T",
		"Ú": "U",
		"Ů": "U",
		"Ý": "Y",
		"Ž": "Z",
	}
}


ui_main_window, qt_base_class = uic.loadUiType(gui_path)

class MyApp(QMainWindow, ui_main_window):        
	
	def __init__(self):
		QMainWindow.__init__(self)
		ui_main_window.__init__(self)
		self.setupUi(self)
		self.radio_button_adfgx.setChecked(True)
		self.button_encrypt.clicked.connect(self.encryption)
		self.button_decrypt.clicked.connect(self.decryption)
		self.button_randomize_table.clicked.connect(self.show_random_table)
		self.button_load_saved_table.clicked.connect(self.load_table)
		self.button_save_table.clicked.connect(self.save_table)


	def pre_transformation_process(self, text:str, keyword:str, mode:str) -> list:
		if tb.is_table_corrupted(gui.read_text_edit_table(self)): 
			raise Exception("Table is corrupted!")
		
		tb.fix_table_appearance(self, gui.read_text_edit_table(self))	

		matrix = tb.get_matrix(self)
		table_type = str(int(len(tb.flatten_matrix(matrix))**0.5))
		
		gui.auto_check_radio_button(self, table_type)

		gui.ui_print(self, f"----------{mode.upper()}---------")
		
		filtered_text = ftr.filter_user_input(text, LANGUAGE_RULES, table_type)
		gui.ui_print(self, "Filtered Text :: " + filtered_text)

		filtered_keyword = ftr.convert_to_indexes(
			ftr.filter_user_input(keyword, LANGUAGE_RULES, table_type)
		)
		gui.ui_print(self, "Filtered Keyword :: " + " ".join(filtered_keyword))

		return [filtered_text, filtered_keyword, matrix, table_type]


	def encryption(self):
		try:
			text = str(self.input_encrypt_text.text())
			keyword = str(self.input_encrypt_password.text())

			filtered_text, filtered_keyword, matrix, table_type = self.pre_transformation_process(text, keyword, "encryption")

			ftr.alarm_on_user_input(filtered_text, filtered_keyword)

			substitution = cph.encrypt_substitution(filtered_text, matrix)
			transposition = cph.encrypt_transposition(filtered_keyword, substitution)
			gui.ui_print(self, "Substitution ::\n" + tb.print_table(transposition["st"]))
			gui.ui_print(self, "Transposition ::\n" + tb.print_table(transposition["tt"]))

			gui.display_encryption(self, transposition["ct"])

		except Exception as e:
			gui.showError(e)


	def decryption(self) -> None:
		try:
			text = str(self.input_decrypt_text.text())
			keyword = str(self.input_decrypt_password.text())

			filtered_text, filtered_keyword, matrix, table_type = self.pre_transformation_process(text, keyword, "decryption")

			transposition = cph.decrypt_transposition(filtered_keyword, text)
			gui.ui_print(self, "Transposition ::\n" + tb.print_table(transposition["tt"]))
			gui.ui_print(self, "Substitution :: \n" + tb.print_table(transposition["st"]))
			
			substitution = cph.decrypt_substitution(transposition['st'], matrix)
			gui.ui_print(self, "Pre-decryption :: " + substitution)

			plain_text = ftr.defilter_user_input(substitution, LANGUAGE_RULES, table_type)

			gui.display_decryption(self, plain_text)

		except Exception as e:
			gui.showError(e)


	def show_random_table(self): 
		cipher_type = gui.checked_cipher_type(self)

		table = tb.create_matrix(
			LANGUAGE_RULES[str(cipher_type)]["alphabet"],
			cipher_type
		)

		formated_table = tb.format_matrix_to_table(table)

		gui.write_text_edit_table(self, formated_table)


	def save_table(self):
		try:
			table = gui.read_text_edit_table(self)
			path = fs.get_full_path("data\\user_table.txt")

			if tb.is_table_corrupted(table): raise Exception

			tb.fix_table_appearance(self, gui.read_text_edit_table(self))	
			
			fs.write_txt_file(path, table)

			gui.ui_print(self, "Table saved to file at: "+path)
		except Exception as e:
			gui.showError(e)	#"Table is corrupted!"""


	def load_table(self):
		try:
			table = fs.read_txt_file(fs.get_full_path("data\\user_table.txt"))

			if tb.is_table_corrupted(table): raise Exception("The file containing table data is corrupted.")

			gui.write_text_edit_table(self, table)

			tb.fix_table_appearance(self, gui.read_text_edit_table(self))	

			gui.ui_print(self, "Table Loaded from file.")
		except Exception as e:
			gui.showError(e)


if __name__ == "__main__":
	text = "útok na čeňka v 15:00"
	keyword = "petrklíč"
	matrix = [
		['N', 'A', '1', 'C', '3', 'H'],
		['8', 'T', 'B', '2', 'O', 'M'],
		['E', '5', 'W', 'R', 'P', 'D'],
		['4', 'F', '6', 'G', '7', 'I'],
		['9', 'J', '0', 'K', 'L', 'Q'],
		['S', 'U', 'V', 'X', 'Y', 'Z'],
	]


	table_type = str(int(len(tb.flatten_matrix(matrix))**0.5))
	
	filtered_text = ftr.filter_user_input(text, LANGUAGE_RULES, table_type)
	print("Filtered Text :: " + filtered_text)

	filtered_password = ftr.filter_user_input(keyword, LANGUAGE_RULES, table_type)
	print("Filtered Keyword :: " + filtered_password)

	substitution = cph.encrypt_substitution(filtered_text, matrix)
	print("Substitution 1 :: " + substitution)

	transposition = cph.encrypt_transposition(filtered_password, substitution)
	print("Substitution :: " + transposition["st"])
	print("Transposition :: " + transposition["tt"])

	print("ciphered_text", transposition["ct"])


	transposition = cph.decrypt_transposition(filtered_password, transposition["ct"])
	print("Transposition :: " + transposition["tt"])
	print("Substitution :: " + transposition["st"])
	
	substitution = cph.decrypt_substitution(transposition['st'], matrix)
	print("Plain text :: " + substitution)

	plain_text = ftr.defilter_user_input(substitution, LANGUAGE_RULES, table_type)

	print("encrypted", plain_text)

 	#petrklíčekČc
	#PETRKLICEKCC
	#       0             