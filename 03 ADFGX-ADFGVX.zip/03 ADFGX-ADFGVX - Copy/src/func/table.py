import random, math
try:
	from src.func.gui import write_text_edit_table, read_text_edit_table
except:
	try:
		from func.gui import write_text_edit_table
	except:
		from gui import write_text_edit_table


def create_matrix(chars:list, size:int, randomize = True) -> list[list]:
	""":size - len(table_elements)**0.5"""
	matrix = []

	if randomize:
		random.shuffle(chars)

	for i in range(0, size**2, size):
		matrix.append(chars[i:i+size])

	return matrix


def format_matrix_to_table(matrix:list[list]) -> str:
	flattened = ""
	for row in matrix:
		for el in row:
			flattened += f"{el} | "

		flattened = flattened[:-3]		# remove last 2 unwanted characters at the end of row
		flattened += "\n"				# add new line at the end of row
	
	flattened = flattened[:-1]			# remove new line at the end of last row

	return flattened


def get_matrix(self) -> list[list]:
	table = read_text_edit_table(self)
	raw_table = table.replace(" ", "").replace("|", "").replace("\n", "")
	size = int(math.sqrt(len(raw_table)))
	return create_matrix(raw_table, size, False)


def flatten_matrix(matrix:list[list]) -> list:
	table = format_matrix_to_table(matrix)
	formatted_table = table.replace(" ", "").replace("|", "").replace("\n", "")
	return list(formatted_table)


def is_table_corrupted(table:str) -> bool:
	line = set(table.replace(" ", "").replace("|", "").replace("\n", ""))
	length = len(line)
	return False if length == 25 or length == 36 else True


def fix_table_appearance(self, table:str) -> None:
	raw = table.replace(" ", "").replace("|", "").replace("\n", "").upper()
	size = 5 if len(raw) == 25 else 6
	matrix = create_matrix(list(raw), size, False)
	format_martix = format_matrix_to_table(matrix)
	write_text_edit_table(self, format_martix)


def print_table(text:str) -> str:	
	return text.replace(" ", "\n")

if __name__ == "__main__":
	a = create_matrix(['a', 'b', 'c','d'], 2)
	print(a)