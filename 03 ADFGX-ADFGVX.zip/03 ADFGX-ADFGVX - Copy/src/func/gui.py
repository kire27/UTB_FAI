from datetime import datetime
from PyQt5.QtWidgets import QMessageBox


def ui_print(ui, value:str):
	'''Console log into ui
	:ui - class element
	:value - text to display
	'''
	text = ui.text_edit_terminal_output.toPlainText()
	new_text = datetime.now().strftime("%H:%M:%S.%f")[:-3] + " | " + str(value)+ '\n\n' + text+'\n'
	ui.text_edit_terminal_output.setPlainText(new_text)


def checked_cipher_type(self) -> int:
	if self.radio_button_adfgx.isChecked():
		return 5
	else:
		return 6


def auto_check_radio_button(self, table_type:str) -> None:
	if table_type == "5":
		self.radio_button_adfgx.setChecked(True)
	else:
		self.radio_button_adfgvx.setChecked(True)


def display_encryption(self, value):
	self.text_edit_encrypt_output.setPlainText("".join(value))


def display_decryption(self, value):
	self.text_edit_decrypt_output.setPlainText(value)


def showError(error_msg):
	error_message = QMessageBox()
	error_message.setWindowTitle('Error')
	error_message.setText(str(error_msg))
	error_message.setStandardButtons(QMessageBox.Ok)
	error_message.exec_()


def read_text_edit_table(self) -> str:
	return self.text_edit_table.toPlainText()


def write_text_edit_table(self, text:str) -> None:
	self.text_edit_table.setPlainText(text)

	