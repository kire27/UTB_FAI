import os


def read_txt_file(path:str):
	with open(path, "r", encoding="utf8") as file:
		return file.read()


def write_txt_file(path:str, data):
	with open(path, "w", encoding="utf8") as file:
		file.write(data)


def get_full_path(file_path):
	dir_path = os.path.dirname(os.path.realpath(__file__))
	src_dir = "\\".join(dir_path.split("\\")[:-1])
	return os.path.join(src_dir, file_path)
