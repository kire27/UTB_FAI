try:
	from src.func.table import flatten_matrix
	from src.func.filters import recursive_separation
except:
	try:
		from func.table import flatten_matrix
		from func.filters import recursive_separation
	except:
		from table import flatten_matrix
		from filters import recursive_separation


def encrypt_substitution(text:str, matrix:list[list]) -> str:
	flat_matrix = flatten_matrix(matrix)
	size = len(flat_matrix)
	substitution_result = ""

	if size == 25:
		substitute = list("ADFGX")
	elif size == 36:
		substitute = list("ADFGVX")
	else:
		raise Exception("Matrix is incorrect!")

	for char in text:
		for y in range(len(matrix)):
			if char in matrix[y]:
				x = matrix[y].index(char)
				substitution_result += substitute[y] + substitute[x]
				
	return substitution_result


def encrypt_transposition(keyword:str, substitution:str) -> dict:
	def empty_spaces_size(k:int, s:int) -> int:
		if s > 0:
			return empty_spaces_size(k, s-k)
		else:
			return abs(s)

	columns = len(keyword)
	empty_spaces = empty_spaces_size(columns, len(substitution))
	for _ in range(empty_spaces):
		substitution += "_"

	transposition = {}

	for k in range(columns):
		for st in range(0, len(substitution), columns):
			key = keyword[k]
			transposition[key] = transposition.get(key, "") + substitution[k+st]

	sorted_keyword = sorted(keyword)
	ciphered_text = ""

	for char in sorted_keyword:
		ciphered_text += transposition[char] + " "

	return {
		"st": "".join(recursive_separation(list(substitution), len(keyword), " ")),
		"tt": " ".join(list(transposition.values())),
		"ct": ciphered_text,
	}


def decrypt_substitution(text:str, matrix:list[list]) -> str:
	flat_matrix = flatten_matrix(matrix)
	size = len(flat_matrix)
	text = text.replace(" ", "").replace("_", "")
	plain_text = ""

	if size == 25:
		substitute = list("ADFGX")
	elif size == 36:
		substitute = list("ADFGVX")
	else:
		raise Exception("Matrix is incorrect!")
	
	for part in range(0, len(text)-1, 2):
		try:
			x = substitute.index(text[part]) 
			y = substitute.index(text[part+1])
			plain_text += matrix[x][y]
		except: 
			pass

	return plain_text


def decrypt_transposition(keyword:list, cipher:str) -> dict:
	cipher = cipher.replace(" ", "")
	columns = len(keyword)
	rows = int(len(cipher)/columns)
	sorted_keyword = sorted(keyword)
	transposition = {}

	try:
		k = 0
		for c in range(0, len(cipher), rows):
			key = sorted_keyword[k]
			transposition[key] = cipher[c:c+rows]
			k += 1
	except:
		raise Exception("Password doesn't match")
	
	substitution = ""

	for i in range(rows):
		for c in keyword:
			substitution += transposition[c][i]
		substitution += " "

	return {
		"tt": " ".join(list(transposition.values())),
		"st": substitution
	}


if "__main__" == __name__:
	matrix = [
		['N', 'A', '1', 'C', '3', 'H'],
		['8', 'T', 'B', '2', 'O', 'M'],
		['E', '5', 'W', 'R', 'P', 'D'],
		['4', 'F', '6', 'G', '7', 'I'],
		['9', 'J', '0', 'K', 'L', 'Q'],
		['S', 'U', 'V', 'X', 'Y', 'Z'],
	]
	# input = "UTOK NA CENKA V 1500"
	input = "ATTACK_AT_1200_AM"
	cipher = "DDFF VVF_ GGD_ DAXV VAF_ DFA_ AAV_ ADF_ "
	# keyword = "PETRKLIC"
	keyword = "PRIVACY"

	e_substitution = encrypt_substitution(input, matrix)
	e_transposition = encrypt_transposition(keyword, e_substitution)
	print("///", e_transposition["st"])
	print("///", e_transposition["tt"])
	print("///", e_transposition["ct"])

	d_transposition = decrypt_transposition(keyword, e_transposition["ct"])
	d_substitution = decrypt_substitution(d_transposition['st'], matrix)

	print("///", d_transposition["tt"])
	print("///", d_transposition["st"])
	print("///", d_substitution)

