def recursive_separation(list:list, index:int, element:any, _i=0) -> list:
	'''Recursively separate list at every instance of index length in list'''
	if _i+index >= len(list): return list        # if i+5 is bigger than list length then we don't have to insert element
	return recursive_separation(
		list[:_i+index] + [element] + list[_i+index:], 
		index,
		element,
		_i+index+1
	)


def alarm_on_user_input(text:str, keyword:str):
	if len(keyword) < 2:
		raise Exception('Klíč je příliš malej.')
	if len(text)/1.5 < len(keyword):
		raise Exception('Pro zachování odolnosti šifry je třeba zkrátit klíčové slovo nebo prodloužit text.\nDuplikáty v klíči se neberou v úvahu.')


def filter_user_input(text: str, lang_rules:dict, type:str) -> str:
	diacritics:dict = lang_rules["diacritics"]
	allowed_chars:list = lang_rules[type]["alphabet"]
	specials:dict = lang_rules[type]["special"]
	text = text.upper()
	
	# replace diacritics and special characters
	for key, val in (diacritics | specials).items(): 
		text = text.replace(key, val)

	if type == "5":
		replacable = lang_rules[type]["replacable"]
		text = text.replace(replacable[0], replacable[1])
	elif type == "6": 
		pass
	else:
		raise Exception(f"Invalid type/size of Matrix: {type}. Triggered at 'filter_user_input'")

	# remove non alphabetical characters
	text = "".join(list(filter(
		lambda x: x in allowed_chars, list(text)
	)))

	return text


def defilter_user_input(text: str, lang_rules:dict, type:str) -> str:
	for key, value in lang_rules[type]["special"].items():
		text = text.replace(value, key)
	return text


def convert_to_indexes(value:str) -> list:
	value_replacements = [str(i) for i in range(len(value))]
	new_value = list(value)

	for i, val in enumerate(sorted(value)):
		index = new_value.index(val)
		new_value[index] = value_replacements[i]

	return new_value


if __name__ == "__main__":
	test = "PETRKLICCCEK"

	a = convert_to_indexes(test)
	print(a)
	print(sorted(a))
